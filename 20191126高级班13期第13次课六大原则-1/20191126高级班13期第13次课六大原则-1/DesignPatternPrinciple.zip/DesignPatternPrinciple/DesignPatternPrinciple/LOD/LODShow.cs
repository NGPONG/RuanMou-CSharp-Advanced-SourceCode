﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.LOD
{
    /// <summary>
    /// 迪米特法则(最少知道原则):一个对象应该对其他对象保持最少的了解。
    /// 只与直接的朋友通信。
    /// 
    /// 尽可能的减少对象之间的依赖！ 
    /// 因为C#语言是面向对象语言，万物皆对象，各个对象之间的交互才行成各种功能！
    /// 
    /// 类和类之间的关系：分为两个维度；
    ///     纵向：继承   实现（相似度几乎100%）
    ///     横向：依赖 （出现在方法中的其他对象）
    ///  
    /// 如果说调用BCL（框架内置的） 除外
    ///  
    ///高内聚低耦合：
    ///       迪米特法则：其实就是降低了类之间的耦合； 多包几层   拆分大法4 
    ///三层： UI层  BLL   DLL
    /// 
    ///去掉内部依赖：
    ///  降低访问修饰符的权限：
    ///  public
    ///  private
    ///  protected
    ///  internal
    ///  protected internal 
    ///  
    /// 迪米特法则： 依赖别人更少，也让别人了解的更少！
    /// 
    /// </summary>
    public class LODShow
    {
        public static void Show()
        {
            Console.WriteLine("************************");
            School school = new School()
            {
                SchoolName = "C#.Net 培训教育",
                ClassList = new List<Class>()
                {
                    new Class()
                    {
                        ClassName="高级班",
                        StudentList=new List<Student>()
                        {
                            new Student()
                            {
                                StudentName="xxx学员"
                            },
                            new Student(){
                                Id=123,
                                StudentName="阳光下的微笑"
                            },
                             new Student(){
                                Id=234,
                                StudentName="HYl"
                            }
                        }
                    }
                }
            };

            school.Manage();
        }
    }
}
