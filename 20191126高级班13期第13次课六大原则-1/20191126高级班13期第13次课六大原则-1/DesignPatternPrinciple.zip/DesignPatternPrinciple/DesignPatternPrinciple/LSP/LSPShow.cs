﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.LSP
{
    /// <summary>
    /// 里氏替换原则：任何使用基类的地方，都可以透明的使用其子类   
    /// 继承：多态性
    /// 
    /// 继承：子类拥有基类的一切属性和行为，任何基类出现的地方都可以用子类代替
    /// 
    /// 继承+ 透明（安全，不会出现行为不一致的情况）
    /// 
    /// 在创建对象的收尽量使用  父类  做变量的声明；为了能够更加灵活
    /// 
    /// 
    /// 1 父类有的，子类是必须有的；
    ///    如果出现子类不应该有的东西，那就需要断掉继承；
    ///   （可以再来一个父类，在这个父类里面只包含应该有的东西）
    /// 
    /// 2 子类可以拥有自己的属性和行为
    ///   子类出现的地方  父类不一定能够代替
    ///    我喜欢小动物，我一定喜欢狗狗，
    ///    如果我喜欢狗狗，却不一定喜欢小动物
    ///    
    /// 3  父类实现的东西，子类就不要再写 （就是避免使用new 关键字隐藏）
    ///    使用了这个关键字以后可能会出现点意外
    ///    建议使用抽象类 或者虚方法 来进行修改父类的行为
    /// 
    /// </summary>
    public class LSPShow
    {
        public static void Show()
        {
            Console.WriteLine("***************************");
            //Poly.Test();
            //{
            //    People chinese = new Chinese();
            //    chinese.Traditional();
            //}
            //{
            //    People chinese = new Hubei();
            //    chinese.Traditional(); 
            //}
            {
                Chinese hubei = new Hubei();
                hubei.SayHi();

                //如果项目组来了一个新人：

                var hubei1 = new Hubei(); 
                hubei1.SayHi();
            }

        }

        private static void DoChinese(Chinese people)
        {
            Console.WriteLine($"{people.Id} {people.Name} {people.Kuaizi}");
            people.SayHi();
        }

        private static void DoHubei(Hubei people)
        {
            Console.WriteLine($"{people.Id} {people.Name} {people.Kuaizi}");
            people.SayHi();
        }

    }
}
