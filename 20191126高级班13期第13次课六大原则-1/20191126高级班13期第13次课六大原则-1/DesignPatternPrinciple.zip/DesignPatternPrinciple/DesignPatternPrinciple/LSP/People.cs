﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.LSP
{
    public class People
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public void Traditional()
        {
            Console.WriteLine("仁义礼智信 温良恭俭让 ");
        }
    }

    public class Chinese : People
    {
        public string Kuaizi { get; set; }
        public void SayHi()
        {
            Console.WriteLine("早上好，吃了吗？");
        }

    }

    public class Hubei : Chinese
    {
        public string Majiang { get; set; }
        public new void SayHi() //new  隐藏父类方法
        {
            Console.WriteLine("早上好，过早了么？");
        }
    }


    public class Animal
    { 
        public int Id { get; set; }
        public string Name { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class Japanese  //: People  //C# 中是强继承  
    {
        public int Id { get; set; }
        public string Name { get; set; }

        //public new void Traditional()
        //{
        //    Console.WriteLine("忍者精神 ");
        //    throw new Exception();
        //} 


        public void Ninja()
        {
            Console.WriteLine("忍者精神 ");
        }

    }

}
