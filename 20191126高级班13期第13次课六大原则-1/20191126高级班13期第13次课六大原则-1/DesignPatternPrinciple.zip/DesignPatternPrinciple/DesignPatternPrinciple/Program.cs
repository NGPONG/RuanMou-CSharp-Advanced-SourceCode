﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple
{
    /// <summary>
    /// 1.  单一职责原则（Single Responsibility Principle）
    /// 2.  里氏替换原则（Liskov Substitution Principle）
    /// 3.  迪米特法则  （Law Of Demeter）
    /// 4.  依赖倒置原则（Dependence Inversion Principle）
    /// 5.  接口隔离原则（Interface Segregation Principle） 
    /// 6.  开闭原则    （Open Closed Principle) 
    /// 
    ///  同学们  大家晚上好！
    ///  能看到老师屏幕的，能听到老师讲话（声音很清晰）  刷个1
    ///  
    /// 
    /// 设计模式:面向对象语言开发过程中，遇到的各种场景和问题，针对于这些问题提出的解决方案和思路，进行的总结；有固定的套路！
    /// 
    /// 设计模式六大原则：建议，就是在面向对象语言开发中，推荐的一些指导性建议，没有明确的套路，可能会在有些场景下会忽略/违背他，这些建议其实是开发前辈们总结下，我们也算是站在前辈的肩膀上学习
    /// 
    /// </summary>
    class Program
    { 
        //现在是22：07  大家开始提问&休息 22：10 开始答疑！期间老师不说话！
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("欢迎来到.net高级班vip课程；我是Richard老师！");
                {
                    //Console.WriteLine("*******************单一职责原则********************");
                    //SRP.SRPShow.Show();
                }
                {
                    //Console.WriteLine("*******************里氏替换原则********************");
                    //LSP.LSPShow.Show();
                }
                {
                    Console.WriteLine("*******************迪米特法则********************");
                    LOD.LODShow.Show();
                }
                {
                    //Console.WriteLine("*******************依赖倒置原则********************");
                    //DIP.DIPShow.Show();
                }
                {
                    //Console.WriteLine("*******************接口隔离原则********************");
                    //ISP.ISPShow.Show();
                }
                {
                    //Console.WriteLine("*******************开闭原则********************");
                    //OCP.OCPShow.Show();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.Read();
        }
    }
}
//静态类：静态方法不占内存  静态字段--唯一的占据内存 不会释放的
