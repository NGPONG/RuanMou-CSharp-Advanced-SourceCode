﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.SRP
{
    /// <summary>
    /// 封装
    /// 动物类
    /// 简单意味着稳定
    /// </summary>
    public class Animal
    {
        private string _Name = null;
        public Animal(string name)
        {
            this._Name = name;
        }
        /// <summary>
        ///  
        /// </summary>
        public void Breath()
        {
            if (this._Name.Equals("鸡"))
            {
                Console.WriteLine($"{this._Name}:呼吸空气！");
            }
            else if (this._Name.Equals("鱼"))
            {
                Console.WriteLine($"{this._Name}:呼吸水！");
            } 
        }
         
        /// <summary>
        /// 在这个时候，我们就应该要考虑 拆分
        /// </summary>
        public void Action()
        {
            if (this._Name.Equals("鸡"))
            {
                Console.WriteLine($"{this._Name}:Flying！");
            }
            else if (this._Name.Equals("鱼"))
            {
                Console.WriteLine($"{this._Name}:Swimming！");
            }

            
        }
    }
}
