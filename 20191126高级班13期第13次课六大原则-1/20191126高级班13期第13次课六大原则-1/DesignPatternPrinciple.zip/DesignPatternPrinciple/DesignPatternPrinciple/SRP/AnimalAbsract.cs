﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.SRP
{
    /// <summary>
    /// 抽象类
    /// </summary>
    public abstract class AnimalAbsract
    {
        public string _Name = null;
        public AnimalAbsract(string name)
        {
            this._Name = name;
        }
        /// <summary>
        ///  
        /// </summary>
        public abstract void Breath();

        /// <summary>
        /// 在这个时候，我们就应该要考虑 拆分
        /// </summary>
        public abstract void Action();

    }
}
