﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.SRP
{
   
    public class Chicken:AnimalAbsract
    {
        
        public Chicken() : base("鸡")
        {
           
        } 

        public override void Action()
        {
            Console.WriteLine($"{this._Name}:Flying！");
        }

        public override void Breath()
        {
            Console.WriteLine($"{this._Name}:呼吸空气！");
        }
    }
}
