﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.SRP
{

    public class Fish : AnimalAbsract
    {

        public Fish() : base("鱼")
        {

        } 

        public override void Action()
        { 
            Console.WriteLine($"{this._Name}:Swimming！");
        }

        //如果某一种动物的动作改变了，这里只需要修改当前这类
        public override void Breath()
        {
            Console.WriteLine($"{this._Name}:呼吸水！");
        }
    }
}
