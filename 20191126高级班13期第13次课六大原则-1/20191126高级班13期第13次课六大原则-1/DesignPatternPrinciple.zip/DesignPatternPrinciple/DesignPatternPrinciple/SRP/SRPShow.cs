﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternPrinciple.SRP
{
    /// <summary>
    /// 单一职责原则：
    /// 
    /// 类T负责两个不同的职责：职责P1，职责P2。当由于职责P1需求发生改变而需要修改类T时，
    /// 有可能会导致原本运行正常的职责P2功能发生故障。 这就违背了单一职责
    /// 
    /// 一个类只负责一件事儿
    /// 一个方法只负责一件事儿
    /// 
    /// 写了太多的分支判断，取执行各自的业务逻辑的时候，就容易出现职责不单一
    /// 如何解决？
    /// 
    /// 可以拆分：
    /// 
    /// 类拆分： 父类 + 子类
    ///    每个类就很简单，类内部很简单，简单就意味着稳定,稳定就是开发永恒的追求
    ///   
    /// 拆分以后：代码量就变多了，类增多了，（解读量增大了，理解成本增大了）
    ///  
    /// 究竟在什么时候需要遵循这个单一职责呢?
    /// 如果方法够简单，类够少，其实违背一下这个单一职责也无所谓！ 
    /// 如果方法多了，业务逻辑负责，建议遵循单一职责！
    /// 
    /// 建议一个方法内部的代码行数不要超过50；
    /// 方法的单一职责：一个方法只负责一件事儿，（根据职责分拆小方法，避免分支逻辑判断）
    /// 类的单一职责：一个类只负责一件事儿
    /// 类库的单一职责： 一个类库应该职责清晰
    /// 系统层面的单一职责：为通用的功能分拆系统
    /// 
    /// 
    /// </summary>
    public class SRPShow
    {
        public static void Show()
        {
            {
                Animal animal = new Animal("鸡");//呼吸空气
                animal.Breath();
                animal.Action();
            }
            {
                Animal animal = new Animal("鱼"); // 呼吸水
                animal.Breath();
                animal.Action();
            }
            {
                Animal animal = new Animal("牛"); // 呼吸空hi
                animal.Breath();
                animal.Action();
            }
            {
                Animal animal = new Animal("蚯蚓"); // 呼吸泥土
                animal.Breath();
                animal.Action();
            }

            {
                AnimalAbsract animal = new Chicken();
                animal.Breath();
                animal.Action();
            }

        }
    }
}
