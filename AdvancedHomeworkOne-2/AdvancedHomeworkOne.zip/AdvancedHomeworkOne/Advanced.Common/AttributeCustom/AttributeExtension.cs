﻿using Advanced.Common.AttributeCustom.Validate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Common.AttributeCustom
{
    public static class AttributeExtension
    {
        /// <summary>
        /// 获取额外信息
        /// </summary>
        /// <param name="prop"></param>
        /// <returns></returns>
        public static string GetRemark(this PropertyInfo prop)
        {
            if (prop.IsDefined(typeof(RemarkAttribute), true))
            {
                var attr = prop.GetCustomAttribute(typeof(RemarkAttribute), true) as RemarkAttribute;
                return attr._Remark;
            }
            else
            {
                return prop.Name;
            }
        }
         
        public static List<ValidateErrorModle> Validate<T>(T t)
        {
            List<ValidateErrorModle> errorList = new List<ValidateErrorModle>();
            Type type = typeof(T);
            foreach (PropertyInfo prop in type.GetProperties())
            {
                if (prop.IsDefined(typeof(AbstractValidateAttribute), true))
                {
                    var attr = prop.GetCustomAttribute(typeof(AbstractValidateAttribute), true) as AbstractValidateAttribute;
                    var oValue = prop.GetValue(t);

                    var errorModel = attr.Validate(oValue);
                    errorList.Add(errorModel);
                }
            }
            return errorList;
        }
    }
}
