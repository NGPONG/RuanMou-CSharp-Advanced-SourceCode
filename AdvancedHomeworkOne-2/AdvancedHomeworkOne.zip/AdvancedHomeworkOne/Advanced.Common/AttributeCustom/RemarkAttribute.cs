﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Common.AttributeCustom
{
    [AttributeUsage(AttributeTargets.Property)]
    public class RemarkAttribute : Attribute
    { 
        //必填的放构造函数，选填的用属性
        ////public RemarkAttribute(string remark)
        ////{
        ////    this._Remark = remark;
        ////}
        public string _Remark { get; set; }

        public string GetRemark()
        {
            return this._Remark;
        }
    }
}
