﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Common.AttributeCustom.Validate
{
    /// <summary>
    /// 异常错误消息
    /// </summary>
    public class ValidateErrorModle
    {
        public bool Result { get; set; }
        public string Message { get; set; }
    }
}
