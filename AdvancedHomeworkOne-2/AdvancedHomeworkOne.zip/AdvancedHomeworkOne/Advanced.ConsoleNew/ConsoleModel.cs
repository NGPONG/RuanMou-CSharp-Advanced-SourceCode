﻿using Advanced.Common.AttributeCustom;
using Advanced.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.ConsoleNew
{
    public static class ConsoleModel
    {
        public static void Show<T>(this T t) where T : BaseModel
        {
            System.Console.WriteLine("开始输出");
            Type type = t.GetType();
            foreach (var prop in type.GetProperties())
            {
                System.Console.WriteLine($"{prop.GetRemark()}:{prop.GetValue(t)}");
            }
            System.Console.WriteLine("输出结束");
        }

    }
}
