﻿using Advanced.Common;
using Advanced.IService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Factory
{
    public class SimpleFactory
    { 
        //public static readonly string factoryConfig = ConfigurationManager.AppSettings["factoryConfig"];

        private static string factoryConfig = ConfigurationManager.AppSettings["factoryConfig"];
        private static string DllName = factoryConfig.Split(',')[1];
        private static string TypeName = factoryConfig.Split(',')[0];
        public static IServiceDal CreateInstentce()
        {
            Assembly assembly = Assembly.Load(DllName);
            Type type = assembly.GetType(TypeName);
            return (IServiceDal)Activator.CreateInstance(type);
        }
    }

}
