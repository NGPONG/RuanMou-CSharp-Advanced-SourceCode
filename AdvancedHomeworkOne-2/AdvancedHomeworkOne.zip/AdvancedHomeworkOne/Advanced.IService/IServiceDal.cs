﻿using Advanced.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.IService
{
    public interface IServiceDal
    {
        bool Add<T>(T t) where T : BaseModel;
        bool Delete<T>(T t) where T : BaseModel;
        bool Update<T>(T t) where T : BaseModel;
        T Find<T>(int id) where T : BaseModel;
        List<T> FindAll<T>() where T : BaseModel;

    }
}
