﻿using Advanced.Factory;
using Advanced.IService;
using Advanced.Model;
using Advanced.Service;
using System;
using Advanced.ConsoleNew;
using Advanced.Common.AttributeCustom;
using Advanced.Common.AttributeCustom.Validate;
using System.Collections.Generic;

namespace Advanced.Main
{
    class Program
    {
        // 能听到老师讲话、能看到老师屏幕  刷个1

        ///然后我们点评作业
        /// <summary>
        /// 作业点评 
        ///    提交作业的数量有待提高
        ///    有存在不写说明的
        ///     
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            try
            {
                System.Console.WriteLine("欢迎大家来到.Net高级班的第一次作业课，我是Richard老师！今天我们来一次作业课！");
                IServiceDal service = new ServiceDal();
                IServiceDal serviceDal = SimpleFactory.CreateInstentce();
                Company company = serviceDal.Find<Company>(1);

                Console.WriteLine("************输出属性******************");
                ///输出属性
                ConsoleModel.Show<Company>(new Company()
                {
                    Name = "Richard",
                    CreateTime = DateTime.Now,
                    CreatorId = 1,
                    Id = 134,
                    LastModifierId = 1,
                    LastModifyTime = DateTime.Now
                });

                var user = new UserModel()
                {
                    Email = "",
                    Mobile = ""
                }; 
                List<ValidateErrorModle> errorList = AttributeExtension.Validate<UserModel>(user);



            }
            catch (Exception ex)
            {
                throw ex;
            }

            System.Console.ReadLine();
        }
    }
}
