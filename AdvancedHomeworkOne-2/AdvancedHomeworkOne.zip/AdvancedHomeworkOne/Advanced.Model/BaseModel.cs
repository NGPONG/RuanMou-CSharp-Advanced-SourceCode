﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Model
{
     
    /// <summary>
    /// Richard 如果父类的存在仅仅只是为了做约束的，建议做成一个抽象类
    /// </summary>
    public abstract class BaseModel
    {
        public int Id { get; set; }
    }
}
