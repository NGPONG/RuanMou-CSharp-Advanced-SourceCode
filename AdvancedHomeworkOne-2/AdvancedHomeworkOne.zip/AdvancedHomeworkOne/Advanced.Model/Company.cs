﻿using Advanced.Common.AttributeCustom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Model
{
    public class Company : BaseModel
    {
       
        [Remark]
        public string Name { get; set; }
        
        public System.DateTime CreateTime { get; set; }
       
        public int? CreatorId { get; set; }
         
        //Richard 加问号表示可空字段 nullable<int> 
        public int? LastModifierId { get; set; }
         
        public DateTime? LastModifyTime { get; set; }
    }
}
