﻿using Advanced.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Advanced.Model;
using System.Data.SqlClient;
using System.Configuration;
using System.Reflection;
using Advanced.Common.AttributeCustom;

namespace Advanced.Service
{
    public class ServiceDal : IServiceDal
    {
        public static readonly string Customers = ConfigurationManager.ConnectionStrings["Customers"].ToString();

        public bool Add<T>(T t) where T : BaseModel
        {
            Type type = typeof(T);
            object oCompany = Activator.CreateInstance(type);
            //Richard Id 是自动增长的，sql语句中应该去除Id的字段 
            //  Richard GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)  过滤掉继承自父类的属性
            string props = string.Join(",", type.GetProperties().Where(p => !p.Name.Equals("Id"))
                //GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)  
                .Select(a => $"[{a.Name}]"));
            string paraValues = string.Join(",", type.GetProperties().Where(p => !p.Name.Equals("Id"))
               //GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)  
               .Select(a => $"@[{a.Name}]"));
            string sql = $"Insert [{type.Name}] ({props}) values({paraValues})";
            var parameters = type.GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly).Select(item => new SqlParameter()
            {
                ParameterName = $"@{item.Name}",
                SqlValue = $"{item.GetValue(t)}"
            });
            // Richard 在拼接sql语句的时候，尽管ID 是Int类型，还是建议大家使用Sql语句参数化 
            //（防止sql注入）
            using (SqlConnection connection = new SqlConnection(Customers))
            {
                SqlCommand sqlCommand = new SqlCommand(sql, connection);
                sqlCommand.Parameters.AddRange(parameters.ToArray());
                connection.Open();
                return sqlCommand.ExecuteNonQuery() > 0;
            }
        }

        public bool Delete<T>(T t) where T : Advanced.Model.BaseModel
        {
            Type type = t.GetType();
            string sql = SqlBuilder<T>.DeleteSql;
            //string sql = $"Delete from [{type.Name}] where Id=@Id";
            using (SqlConnection connection = new SqlConnection(Customers))
            {
                SqlCommand sqlCommand = new SqlCommand(sql, connection);
                sqlCommand.Parameters.Add(new SqlParameter("@Id", t.Id));
                connection.Open();
                return sqlCommand.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// 对饮的类型 所生成的Sql语句是固定不变
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public T Find<T>(int id) where T : BaseModel
        {
            Type type = typeof(T);
            object oCompany = Activator.CreateInstance(type);
            //string sql = $"SELECT {string.Join(",", type.GetProperties().Select(a => $"[{a.Name}]")) } FROM [{type.Name}] where Id=@Id"; 
            string sql = SqlBuilder<T>.FindSql;

            // Richard 在拼接sql语句的时候，尽管ID 是Int类型，还是建议大家使用Sql语句参数化 
            //（防止sql注入）
            using (SqlConnection connection = new SqlConnection(Customers))
            {
                SqlCommand sqlCommand = new SqlCommand(sql, connection);
                sqlCommand.Parameters.Add(new SqlParameter("@Id", id));
                connection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();
                if (reader.Read()) //开始读取
                {
                    //Func<Type, object, SqlDataReader, object> func = ReaderToList;
                    Func<Type, object, SqlDataReader, object> func = (t, o, r) =>
                    {
                        foreach (var prop in t.GetProperties())
                        {
                            prop.SetValue(oCompany, r[prop.GetRemark()] is DBNull ? null : r[prop.GetRemark()]);
                        }
                        return o;
                    };
                    object oResutl = func.Invoke(type, oCompany, reader);

                    return (T)oResutl;
                }
                else  //Richard
                {
                    return null;
                }
            }
        }





        #region Private




        private static object ReaderToList(Type type, object oCompany, SqlDataReader reader)
        {
            foreach (var prop in type.GetProperties())
            {
                prop.SetValue(oCompany, reader[prop.GetRemark()] is DBNull ? null : reader[prop.GetRemark()]);
            }
            return oCompany;
        }
        #endregion


        public List<T> FindAll<T>() where T : Advanced.Model.BaseModel
        {
            Type type = typeof(T);
            //string sql = $"SELECT {string.Join(",", type.GetProperties().Select(a => $"[{a.Name}]")) } FROM [{type.Name}]";

            string sql = SqlBuilder<T>.FindAllSql;

            using (SqlConnection connection = new SqlConnection(Customers))
            {
                SqlCommand sqlCommand = new SqlCommand(sql, connection);
                connection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();
                List<T> datalist = new List<T>();
                while (reader.Read()) //开始读取
                {
                    object oCompany = Activator.CreateInstance(type);
                    ReaderToList(type, oCompany, reader);
                    datalist.Add((T)oCompany);
                }
                return datalist;
            }
        }


        /// <summary>
        /// 这里老师推荐大家把修改和新增 放在同一个方法里面
        /// 修改和删除仅仅只是sql语句不一样 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="t"></param>
        /// <returns></returns>
        public bool Update<T>(T t) where T : Advanced.Model.BaseModel
        {
            Type type = typeof(T);
            object oCompany = Activator.CreateInstance(type);
            //string sql = $"update [{type.Name}]  set {string.Join(",", type.GetProperties().Where(a => !a.Name.Equals("Id")).Select(a => $"[{a.Name}]=@ {a.Name}"))}  where Id =@Id";  
            string sql = SqlBuilder<T>.UpdateSql;
            var parameters = type.GetProperties().Select(item => new SqlParameter()
            {
                ParameterName = $"@{item.Name}",
                SqlValue = $"{item.GetValue(t)}"
            });
            // Richard 在拼接sql语句的时候，尽管ID 是Int类型，还是建议大家使用Sql语句参数化 
            //（防止sql注入）
            using (SqlConnection connection = new SqlConnection(Customers))
            {
                SqlCommand sqlCommand = new SqlCommand(sql, connection);

                sqlCommand.Parameters.AddRange(parameters.ToArray());
                connection.Open();
                return sqlCommand.ExecuteNonQuery() > 0;
            }
        }
    }
}
