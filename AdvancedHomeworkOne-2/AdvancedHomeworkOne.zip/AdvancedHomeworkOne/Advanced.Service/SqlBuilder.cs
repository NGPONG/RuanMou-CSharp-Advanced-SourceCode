﻿using Advanced.Common.AttributeCustom;
using Advanced.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Service
{

    /// <summary>
    /// 针对于不同的类型，生成副本
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class SqlBuilder<T> where T : BaseModel
    {
        public static readonly string FindSql = null;
        public static readonly string DeleteSql = null;
        public static readonly string FindAllSql = null;
        public static readonly string UpdateSql = null;

        static SqlBuilder()
        {
            Type type = typeof(T);
            FindSql = $"SELECT {string.Join(",", type.GetProperties().Select(a => $"[{a.Name}] as {a.GetRemark()}")) } FROM [{type.Name}] where Id=@Id";

            DeleteSql = $"Delete from [{type.Name}] where Id=@Id"; ;

            FindAllSql = $"SELECT {string.Join(",", type.GetProperties().Select(a => $"[{a.Name}] as {a.GetRemark()}")) } FROM [{type.Name}]";

            UpdateSql = $"update [{type.Name}]  set {string.Join(",", type.GetProperties().Where(a => !a.Name.Equals("Id")).Select(a => $"[{a.Name}]=@ {a.Name}"))}  where Id =@Id";
        }
    }
}
